# Reproducibility check: Humble Seed v0.8.7 test suite

This is a pre-registered test suite for a small Python state-machine prototype. The prototype
keeps a hash-chained log and owner-signed checkpoints (Ed25519, via `cryptography`). The
expected outcome of every test was written down and frozen before the suite was written.

The only request is to run it once and report what it prints. No code review is needed.

```
python3 -I falsify_v0_8_7.py
```

- Needs Python 3.10+ and `cryptography`.
- Takes about 5 minutes.
- Uses no network access, and writes only to temporary directories.

Please report:
- the exit code;
- the line that starts with `receipt`;
- the line that starts with `mismatches vs declared`;
- your Python and cryptography versions.
