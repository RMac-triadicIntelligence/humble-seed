from pathlib import Path
import json,hashlib,collections,difflib
R=Path(__file__).resolve().parents[1];P=R/'humble_seed_v0_8_5_candidate_BLIND';E=R/'evidence'
b=json.loads((P/'RESULTS_v0_8_5.json').read_text());d=json.loads((P/'DECLARED_v0_8_5.json').read_text());env=json.loads((E/'environment_integrity.json').read_text());run=json.loads((E/'baseline_run.json').read_text());probes=json.loads((E/'independent_results.json').read_text());diag=json.loads((E/'DIAGNOSTIC_RESULTS_v0_8_5.json').read_text());drun=json.loads((E/'diagnostic_run.json').read_text())
text=f'''# Humble Seed v0.8.5 — independent blind review

2026-10-19. Work restricted to the supplied archive. No other reviews or external sources were retrieved. The included v0.8.4 source was inspected as part of this pack. The candidate and declaration remain unchanged. Sealed commitments were retained; salts and sealed findings were not available, so their contents and chronology were not independently verified.

## Assessment

The frozen battery returns exit **{run['exit_code']}**, with **60/61 candidate tests passing** and **four declared mismatches**. T57 is the only failing candidate test. Its expected error is wrong: the owner refuses the unattested state on checkpoint category sequences before reaching the unattested-tail check. This is a harness expectation defect, not evidence that checkpoint rollback failed.

The independent work found an additional persistence problem: a stale organism object can overwrite a newer saved checkpoint through an ordinary public operation. The external witness detects the resulting rollback, but the latest signed-off state has already been overwritten. An interleaving during sign-off can even make `attest` return True while the saved organism is behind the witness. This deserves repair before treating the candidate as robust across multiple organism sessions.

A second, narrower failure boundary is a directory-fsync error after replacement. Memory is rolled back while the new checkpoint is already visible on disk. Recovery correctly completes from disk, but retrying with the original object fails until it is reloaded. This is a recoverable partial-write outcome, not a demonstrated authorization bypass or a proof of actual power-loss durability.

Within the explicit veto, expiration, foreign-signature, history-rewrite and replay-input cases exercised below, the owner refused the prohibited result. These observations are bounded to the runnable cases; they do not establish universal safety, life, intelligence or emergence.

## Exact frozen execution

- Command: `python3 -I falsify_v0_8_5.py`
- Python: `{env['python']}`
- cryptography: `{env['cryptography']}`
- Platform: `{env['platform']}`
- Exit code: `{run['exit_code']}`
- Elapsed: `{run['elapsed_seconds']:.3f}` seconds
- Candidate SHA-256: `{b['candidate_sha256']}`
- Declaration SHA-256: `{b['declared_sha256']}`
- Original ZIP SHA-256: `{env['input_zip_sha256']}`
- All 11 manifest entries and the two separate candidate/declaration hash checks matched. This establishes internal byte consistency, not independent proof of when a preregistration was frozen.

Verbatim final receipt:

```text
receipt (statuses only, run-independent): {b['receipt']}
```

Frozen candidate results: 60 PASS, 1 FAIL, 0 ERROR. Frozen mutants: 58 KILLED, 2 SURVIVES (null copy and XR4), 1 CRASHED (the intentionally crashing XH). Mutants with errors retain their error lists in the results JSON; crashes are never counted as kills. In particular XL7 is killed by failing tests and also has three newly erroring tests.

## Every mismatch and its diagnosis

| Frozen row | Declared | Measured | Diagnosis |
|---|---|---|---|
| T57_failed_checkpoint_save_changes_nothing | PASS | FAIL | Actual refusal: `IntegrityError: Category sequences do not match the attested checkpoint`. Apply already advanced category sequences, while the failed checkpoint save leaves checkpoint 0 installed. `_verify_attestation` checks gates before the unattested tail. T57 expects `Unattested authorizing event`, so it stops before its later recovery/retry assertions. |
| X10_unattested_tail_check_removed | KILLED, exact T22 + T57 | KILLED by T22 only | T57 does not pass on the frozen candidate, so it cannot contribute a new failure. More importantly, even after correcting T57, gates still refuse first; removing the tail check does not make T57 fail. Its declared exact kill set remains wrong. T22 is the actual tail-check probe. |
| XR2_recovery_never_abandons | KILLED, exact T55 + T57 | KILLED by T55 only | T57's baseline failure excludes it from the original passing set. After the narrow expectation correction, T57 passes the candidate and fails XR2 at recovery, restoring this declared kill set. |
| XR4_install_keeps_memory_on_failed_save | KILLED by T57 | SURVIVES | Its only declared detector, T57, is already nonpassing on the candidate and is excluded. After correcting the expectation, T57 passes the candidate and fails this mutant because memory is at 1 while disk remains 0. The diagnostic shows a missing effective test result in the frozen run, not a surviving exploit in the candidate. |

The exact lines are reproduced in the full frozen stdout appendix. No mismatch was suppressed or reclassified in the original results.

## Separate diagnostic, not a replacement receipt

`independent/falsify_diagnostic.py` changes only T57's expected refusal substring to the actual earlier guard. It uses the original candidate and original frozen declaration. It writes a separate result file.

The diagnostic executes the full battery again: **61/61 PASS**, **59 mutants KILLED**, null copy SURVIVES, intentional XH CRASHED. Exit **{drun['exit_code']}** with **{diag['mismatches']} mismatch**, X10's incorrect exact kill set. Its measured set is T22 alone. T57 should not be added to X10's expected killers.

Diagnostic receipt, explicitly not the frozen receipt:

```text
receipt (statuses only, run-independent): {diag['receipt']}
```

The targeted corrected-T57 experiment additionally demonstrates that XR5 (recovery trusts object) is not detected by T57 when memory and disk agree; T58 remains the detector for that control.

## F1 — stale public writes can erase newer saved state

Priority: high for persistence and availability. No owner-file editing, private-key access, candidate mutation, clock manipulation or concurrent thread is required for the basic reproduction.

Procedure in `stale_public_write`:

1. Hatch and attest checkpoint 0; load a second organism object from that same path.
2. On the first object, sign, apply and attest a verbosity change: saved checkpoint 1, verbosity 0.25, witness 1.
3. On the older object, call `dwell_or_propose` with ordinary non-proposing text. Its `_save` unconditionally writes its entire stale snapshot.
4. A fresh load now reads checkpoint 0 and verbosity 0.50. Local verification succeeds, but owner audit reports rollback and owner attestation reports a non-successor checkpoint.

Selected actual output:

```json
{json.dumps(probes['stale_public_write']['output'],indent=2)}
```

Root cause: `HumbleSeed._save` has no disk-generation comparison or organism write lock. The owner lock serializes owner operations; ordinary organism operations do not participate. Reading the saved checkpoint during recovery fixes the trust source for an intent, but it does not prevent stale writes to that source.

Two related schedules were also executed:

- `advanced_memory_save_during_attest` inserts that same ordinary public write after the current object's checkpoint install and before witness commit. It uses a deterministic hook at the commit boundary to model scheduling, without changing the commit logic. Attest returns True; disk is at 0 and witness at 1; fresh audit refuses.
- `interrupted_commit_stale_write` interrupts witness commit after checkpoint 1 is saved. A stale ordinary write then puts checkpoint 0 back. Recovery sees the witness head on disk, abandons the intent and accepts the old state. Audit returns True at checkpoint 0; the saved signed-off character change is lost. The witness has not finalized checkpoint 1 in this schedule, so this is loss of a saved approved intent, not acceptance of a fabricated mutation.

The outputs for both schedules are in the independent appendix. The sequential reproduction is sufficient to establish the stale-write defect; the hook is only evidence for the specified interleaving, not a broad concurrency stress test.

Impact: a detected rollback can still destroy availability. If the newer in-memory object or a valid snapshot is retained, this experiment can restore progress by attesting it; the code does not reconstruct that overwritten state from its retained witness metadata alone. Do not call this cryptographic forgery, a key bypass, or unconditional permanent loss.

Suggested repair: define and enforce one organism persistence protocol across every writer. Compare the expected saved revision under a shared lock before replacing, and reject or explicitly reconcile stale objects. Coordinate checkpoint install/witness commit with the same protocol. Simply reloading immediately before an unlocked save does not close the race. If multiple organism sessions are intentionally unsupported, enforce that constraint rather than silently accepting stale saves.

## F2 — failure after replacement leaves memory behind disk

Priority: medium for recovery ergonomics; bounded error-injection observation.

`post_replace_fsync_failure` patches only `os.fsync` to raise on the directory descriptor after the new organism checkpoint has already been replaced into its state path. It does not patch replay, signatures, witness logic or `_save`. Before-replacement failures are covered separately by corrected T57.

Actual output:

```json
{json.dumps(probes['post_replace_fsync_failure']['output'],indent=2)}
```

`install_checkpoint` restores checkpoint 0 in RAM on any save exception, although this exception occurs after checkpoint 1 becomes visible on disk. The next attest recovers the approved saved checkpoint to witness 1, then builds a successor from the stale object at 0 and refuses it. Reloading the saved checkpoint succeeds and allows further attestation. The approved intent recovery works; the stale caller is not reconciled.

Suggested repair: represent the post-replacement outcome explicitly. After an indeterminate save, resolve from the saved generation and either synchronize the object or require a reload before further writes. Exercise failures before replacement, after replacement, and on witness persistence. This probe does not establish what survives an actual power loss.

## Executed authority and liveness controls

Each claim here has runnable code and actual output in `independent/review_probes.py` and `evidence/independent_results.json`. Some controls deliberately rerun named shipped tests so their evidence can be compared directly.

| Case exercised | Measured behavior |
|---|---|
| Normal four-crossing session across three categories | All four applied and attested; reload/audit succeeded; mutation sequence 4. |
| Different owner's key at verify_consequence | Refused: organism is not keyed to this owner. This isolates the key guard; it does not exercise a different witness's enrollment guard. |
| Rewritten already-attested history, rehashed chain | Refused: attested history was rewritten. |
| Owner's recorded no; reader disabled | Attestation refused (T41). |
| Forged yes only on organism after genuine owner no | Attestation refused (T47). |
| Expired on owner's clock; re-sign from stale owner session | Attestation refused (T42, T53). |
| Organism recorded expiry, then its clock was wound back | Attestation refused (T43). |
| Signature made outside owner tool, even with correct key | Attestation refused (T46). |
| Saved installed intent, stale object handed to audit | Recovery completes from disk; stale object is refused; fresh object audits and advances (T58). |
| Invalid annotation and clock before issuance | Apply refuses before crossing; valid 2000-character annotation applies and attests (T59). |
| Category no before signing, first and later crossings | Authoritative attestation refused despite organism-only forged yes (T60, T61). |
| Genuine no before a fresh reading is issued, then genuine yes on the original pending reading | Fresh reading applies but initially cannot attest; genuine owner correction releases the veto and reload/audit succeeds (`window_orderings`). This records the intentionally wider owner window, not a bypass. |
| Pending recovery with unreadable state; with unrelated saved checkpoint | Both refuse as RollbackDetected (`pending_recovery_refusals`). |

Apply/replay equality covers the new mutation record, not the owner's separate ledger, expiry and answer checks. Existing T41–T48 intentionally demonstrate that apply can occur before owner attestation refuses it. These are established architectural boundaries, not additional new findings here. No new bypass of those owner checks was demonstrated in the enumerated cases.

## Test validity and scope

The material testing issue is T57's unreachable expected refusal. It also hid XR4's removal of the in-memory rollback and overstated X10 coverage. The full diagnostic and the targeted mutant runs expose this explicitly. Other refusal-message-sensitive kills remain mechanism checks; for example XP1 is accurately renamed and documented as a changed refusal mechanism, while XP1b removes both the finite and window checks. A KILLED label alone should not be read as proof that an unsafe mutation was accepted by the mutant.

The reviewer initially tried to isolate the foreign-key check through a different owner's attest call. That call was stopped earlier by its unrelated witness enrollment rules. The probe setup was corrected to call verify_consequence directly; both the initial failed reviewer assertion and final output are retained. No candidate behavior was modified for that correction.

This review did not build a repair or edit the candidate. The main recommended next work is the shared organism persistence boundary, plus correcting T57 and X10's declared exact kill set. Retain the repaired veto and replay controls while doing so.

## Evidence index

- `input/Claudehumble_seed_v0_8_5_candidate_BLIND.zip`: original input bytes.
- `humble_seed_v0_8_5_candidate_BLIND/`: supplied source, declaration, commitments and unchanged original frozen RESULTS file generated here.
- `evidence/baseline.stdout.txt`, `.stderr.txt`, `baseline_run.json`: exact frozen execution.
- `evidence/environment_integrity.json`: versions, platform, input and manifest hashes.
- `independent/review_probes.py`: reproducible attacks, recovery probes and controls.
- `evidence/independent_results.json`, `independent.stdout.txt`, `independent.stderr.txt`: final independent results.
- `evidence/independent_initial*`: initial reviewer probe setup error, retained transparently.
- `evidence/probes/`: organism, ledger and witness states, plus the before/after stale-write snapshots. Corrected-T57 mutants generated from declaration are retained there. Test keys were ephemeral and not saved.
- `independent/falsify_diagnostic.py`, `evidence/diagnostic*`, `evidence/DIAGNOSTIC_RESULTS_v0_8_5.json`: separately labeled full diagnostic run.
- `independent/build_report.py`: builds this report from saved results.
- `SHA256SUMS`: archive inventory with hashes, excluding itself.

## Appendix A — full frozen tables and verbatim stdout

```text
{(E/'baseline.stdout.txt').read_text()}
```

## Appendix B — complete independent probe output

```text
{(E/'independent.stdout.txt').read_text()}
```

## Appendix C — full diagnostic stdout

```text
{(E/'diagnostic.stdout.txt').read_text()}
```
'''
(R/'REPORT.md').write_text(text)
# A plain UTF-8 copy is convenient for offloading to another reviewer.
(R/'REPORT.txt').write_text(text)
# Compare only the explicit diagnostic source changes; no candidate changes.
original=(P/'falsify_v0_8_5.py').read_text().splitlines(True);changed=(R/'independent/falsify_diagnostic.py').read_text().splitlines(True)
(E/'diagnostic_harness.diff').write_text(''.join(difflib.unified_diff(original,changed,fromfile='frozen/falsify_v0_8_5.py',tofile='independent/falsify_diagnostic.py')))
print(json.dumps({'report_bytes':len(text.encode()),'frozen_receipt':b['receipt'],'diagnostic_receipt':diag['receipt'],'independent_probe_groups':len(probes)},indent=2))
