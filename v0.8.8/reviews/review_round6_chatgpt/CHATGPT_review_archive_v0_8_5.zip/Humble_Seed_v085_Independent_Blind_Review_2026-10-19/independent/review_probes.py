#!/usr/bin/env python3
"""Independent, local-only review. Run: python3 -I independent/review_probes.py
Candidate files remain unchanged. Crash tests patch only a save/fsync scheduling boundary.
All test directories and JSON outputs are retained under evidence/probes/.
"""
from pathlib import Path
import importlib.util,sys,json,copy,os,stat,traceback,shutil
ROOT=Path(__file__).resolve().parents[1]
PACK=ROOT/'humble_seed_v0_8_5_candidate_BLIND'
OUT=ROOT/'evidence'/'probes'
OUT.mkdir(parents=True,exist_ok=True)
def load(path,alias):
 spec=importlib.util.spec_from_file_location(alias,path);m=importlib.util.module_from_spec(spec);sys.modules[alias]=m;spec.loader.exec_module(m);return m
K=load(PACK/'humble_seed_v0_8_5_candidate.py','review_candidate')
PREF='I always prefer shorter answers'
def born(d):
 s=K.HumbleSeed(d/'org');_,pem,_=s.hatch();o=K.OwnerTool(pem,K.OwnerWitness(d/'witness.json'));assert o.attest(s);return s,o

def prop(s,cat='verbosity'):
 r=s.dwell_or_propose(cat,'probe',PREF);assert r['status']=='proposal';return r

def apply(s,o,r):
 a=s.authorize_and_apply(r['proposal_id'],o.sign_proposal(r['payload_to_sign']));assert a is not None;return a

def fresh(s):
 f=K.HumbleSeed(s.data_dir);f.load();return f

def result(fn):
 try:return {'returned':fn()}
 except Exception as e:return {'exception':type(e).__name__,'message':str(e)}

def witness(o,s):return K.OwnerWitness(o.witness.path).ledger[s.organism_id]['sequence']
def disk(s):return json.loads(s._state_path().read_text())
def snapshot(s,name):
 (s.data_dir.parent/(name+'.json')).write_text(s._state_path().read_text())

def stale_public_write(d):
 s,o=born(d);stale=fresh(s)
 apply(s,o,prop(s));assert o.attest(s);snapshot(s,'before_stale_write')
 before={'saved_sequence':disk(s)['checkpoint']['sequence'],'witness_sequence':witness(o,s),'verbosity':disk(s)['character']['verbosity']}
 response=stale.dwell_or_propose('curiosity','ordinary','hmm ok')
 snapshot(s,'after_stale_write');f=fresh(s)
 after={'saved_sequence':f.checkpoint.sequence,'witness_sequence':witness(o,s),'verbosity':f.character['verbosity']}
 aud=result(lambda:o.audit(f));att=result(lambda:o.attest(f))
 assert before['saved_sequence']==1 and after['saved_sequence']==0 and after['verbosity']==0.5
 assert aud.get('exception')=='RollbackDetected' and att.get('exception')=='RollbackDetected'
 return {'before':before,'ordinary_response':response['status'],'after':after,'fresh_audit':aud,'fresh_attest':att,'latest_object_retained_can_repair':result(lambda:o.attest(s))}

def post_replace_fsync_failure(d):
 s,o=born(d);apply(s,o,prop(s))
 original=K.os.fsync;seen=[]
 def fail_directory(fd):
  if stat.S_ISDIR(os.fstat(fd).st_mode):
   saved=disk(s)
   if saved['checkpoint']['sequence']==1:
    seen.append('organism replacement visible before directory fsync')
    raise OSError('injected directory fsync failure AFTER organism os.replace')
  return original(fd)
 K.os.fsync=fail_directory
 try:first=result(lambda:o.attest(s))
 finally:K.os.fsync=original
 state={'memory_sequence':s.checkpoint.sequence,'saved_sequence':disk(s)['checkpoint']['sequence'],'witness_sequence':witness(o,s)}
 retry=result(lambda:o.attest(s));after={'memory_sequence':s.checkpoint.sequence,'saved_sequence':disk(s)['checkpoint']['sequence'],'witness_sequence':witness(o,s)}
 f=fresh(s);aud=result(lambda:o.audit(f));advance=result(lambda:o.attest(f))
 assert state=={'memory_sequence':0,'saved_sequence':1,'witness_sequence':0}
 assert retry.get('exception')=='RollbackDetected' and after['witness_sequence']==1
 assert aud.get('returned') is True and advance.get('returned') is True
 return {'fault_reached':seen,'first_attest':first,'after_failure':state,'same_object_retry':retry,'after_retry':after,'reloaded_audit':aud,'reloaded_attest':advance}

def corrected_T57(d):
 H=load(PACK/'falsify_v0_8_5.py','review_harness')
 # Change only the expected earlier guard. The remaining frozen assertions are identical.
 original=H.T57_failed_checkpoint_save_changes_nothing
 import inspect
 source=inspect.getsource(original).replace('"Unattested authorizing event" in got','"Category sequences do not match the attested checkpoint" in got')
 namespace=dict(vars(H));exec(compile(source,'corrected_T57_expectation.py','exec'),namespace)
 check=namespace['T57_failed_checkpoint_save_changes_nothing']
 decl=json.loads((PACK/'DECLARED_v0_8_5.json').read_text())
 values={}
 for name in ['candidate','X10_unattested_tail_check_removed','XR2_recovery_never_abandons','XR4_install_keeps_memory_on_failed_save','XR5_recovery_trusts_the_object']:
  target=d/name;target.mkdir(parents=True)
  module=K if name=='candidate' else H.build_mutant(name,[tuple(e) for e in decl['mutants'][name]['edits']],d)
  try:values[name]={'status':'PASS','detail':check(module,target)}
  except H.Fail as e:values[name]={'status':'FAIL','detail':str(e)}
  except Exception as e:values[name]={'status':'ERROR','detail':f'{type(e).__name__}: {e}'}
 assert values['candidate']['status']=='PASS'
 assert values['XR4_install_keeps_memory_on_failed_save']['status']=='FAIL'
 assert values['XR2_recovery_never_abandons']['status']=='FAIL'
 assert values['X10_unattested_tail_check_removed']['status']=='PASS'
 return values

def interrupted_commit_stale_write(d):
 s,o=born(d);stale=fresh(s);apply(s,o,prop(s))
 original=o.witness.commit
 def stop(cp):raise OSError('interrupted before witness advance')
 o.witness.commit=stop
 try:first=result(lambda:o.attest(s))
 finally:o.witness.commit=original
 before={'saved_sequence':disk(s)['checkpoint']['sequence'],'witness_sequence':witness(o,s)}
 stale.dwell_or_propose('curiosity','evt','ordinary')
 f=fresh(s);aud=result(lambda:o.audit(f))
 after={'saved_sequence':disk(s)['checkpoint']['sequence'],'witness_sequence':witness(o,s),'verbosity':f.character['verbosity'],'pending_intent':o.witness.pending_for(s.organism_id)}
 assert before=={'saved_sequence':1,'witness_sequence':0}
 assert aud.get('returned') is True and after['pending_intent'] is None and after['verbosity']==0.5
 return {'injected_interruption':first,'before_stale_write':before,'after_stale_write_and_recovery':after,'fresh_audit':aud}

def advanced_memory_save_during_attest(d):
 # Deterministic scheduling of a public write between install and witness advance.
 s,o=born(d);stale=fresh(s);apply(s,o,prop(s));original=o.witness.commit
 def interleave(cp):
  stale.dwell_or_propose('curiosity','ordinary','ordinary use')
  return original(cp)
 o.witness.commit=interleave
 try:att=result(lambda:o.attest(s))
 finally:o.witness.commit=original
 f=fresh(s);aud=result(lambda:o.audit(f))
 assert att.get('returned') is True and f.checkpoint.sequence==0 and witness(o,s)==1 and aud.get('exception')=='RollbackDetected'
 return {'attest':att,'saved_sequence':f.checkpoint.sequence,'witness_sequence':witness(o,s),'fresh_audit':aud}

def authority_controls(d):
 records={}
 # New owner session cannot attest someone else's organism.
 s,o=born(d/'wrong_owner');s2,o2=born(d/'other')
 records['wrong_owner']=result(lambda:o2.verify_consequence(s,s.checkpoint_request()))
 assert records['wrong_owner'].get('exception')=='AttestationRefused'
 # All live checks including reload/audit succeed in the normal path.
 for cat in ['verbosity','formality','curiosity','verbosity']:
  apply(s,o,prop(s,cat));assert o.attest(s)
 f=fresh(s);records['normal_crossings']={'mutation_sequence':f.mutation_sequence,'audit':o.audit(f),'character':f.character}
 # Rewriting attested trace must be refused even if the chain is recomputed.
 for e in s.trace:
  if e.get('event')=='authorized_mutation':e['record']['unverified_annotation']='edited after checkpoint';break
 bodies=[{k:v for k,v in e.items() if k not in ('entry_hash','prev_hash')} for e in s.trace];s.trace=[];s._trace_head='0'*64
 for e in bodies:s._append_trace(e)
 s._save();records['rewritten_attested_history']=result(lambda:o.attest(s))
 assert records['rewritten_attested_history'].get('exception')=='AttestationRefused'
 return records

def repaired_paths_controls(d):
 H=load(PACK/'falsify_v0_8_5.py','review_controls_harness')
 values={}
 for name in ['T41_owner_ledger_refuses_held_crossing','T42_owner_clock_lifetime','T43_organism_expiry_record_honored','T46_reading_must_be_signed_through_owner_tool','T47_forged_yes_does_not_reach_attestation','T53_lifetime_runs_from_first_signing','T58_stale_object_cannot_abandon_an_installed_intent','T59_apply_refuses_what_replay_would_refuse','T60_owner_no_before_signing_holds_first_crossing','T61_owner_no_before_signing_holds_later_crossing']:
  p=d/name;p.mkdir(parents=True);values[name]=getattr(H,name)(K,p)
 return values

def window_orderings(d):
 # Genuine correction in the owner record releases a category veto on a later reading.
 s,o=born(d);y=prop(s);o.answer(s,y['proposal_id'],'no');x=prop(s)
 a=apply(s,o,x);first=result(lambda:o.attest(s))
 o.answer(s,y['proposal_id'],'yes');second=result(lambda:o.attest(s));f=fresh(s)
 assert first.get('exception')=='AttestationRefused' and second.get('returned') is True and o.audit(f)
 return {'fresh_reading_apply':a['status'],'owner_no_before_issuance_attest':first,'genuine_owner_yes_releases':second,'audit':True}

def pending_recovery_refusals(d):
 values={}
 for name in ['unreadable','neither']:
  s,o=born(d/name);apply(s,o,prop(s));original=s.install_checkpoint
  def stop(cp,sig):raise OSError('before install')
  s.install_checkpoint=stop
  try:result(lambda:o.attest(s))
  finally:s.install_checkpoint=original
  if name=='unreadable':s._state_path().write_text('{')
  else:
   data=disk(s);data['checkpoint']['sequence']=999;s._state_path().write_text(json.dumps(data))
  values[name]=result(lambda:o.audit(s));assert values[name].get('exception')=='RollbackDetected'
 return values

TESTS=[corrected_T57,stale_public_write,post_replace_fsync_failure,interrupted_commit_stale_write,advanced_memory_save_during_attest,authority_controls,repaired_paths_controls,window_orderings,pending_recovery_refusals]
all_results={}
for fn in TESTS:
 d=OUT/fn.__name__
 if d.exists():shutil.rmtree(d)
 d.mkdir()
 try:record={'status':'OBSERVED','output':fn(d)}
 except Exception as e:record={'status':'ERROR','error':str(e),'traceback':traceback.format_exc()}
 all_results[fn.__name__]=record;print(json.dumps({fn.__name__:record},sort_keys=True),flush=True)
(OUT.parent/'independent_results.json').write_text(json.dumps(all_results,indent=2,sort_keys=True))
if any(v['status']=='ERROR' for v in all_results.values()):sys.exit(1)
