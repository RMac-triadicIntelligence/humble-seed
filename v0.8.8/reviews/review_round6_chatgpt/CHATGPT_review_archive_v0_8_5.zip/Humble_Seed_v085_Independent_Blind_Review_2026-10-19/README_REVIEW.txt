Humble Seed v0.8.5 — independent blind review — 2026-10-19

Start with REPORT.md. Frozen stdout is evidence/baseline.stdout.txt.
The exact original pack is in input/. Unpacked source is in
humble_seed_v0_8_5_candidate_BLIND/. No candidate or frozen declaration was edited.

Requirements: Python 3.10+, cryptography, POSIX/Linux or macOS, local filesystem.
No network access is used by these tests. All keys created by tests are disposable.

To run the original frozen battery from this directory:
  cd humble_seed_v0_8_5_candidate_BLIND
  python3 -I falsify_v0_8_5.py
Expected original result here: exit 1; four mismatches; see report.

To run the independent probes from this directory:
  python3 -I independent/review_probes.py
Expected exit: 0. Its assertions verify the observed findings and controls;
exit 0 means those observations reproduced, NOT that the candidate is defect free.
The script writes evidence/independent_results.json and keeps state snapshots.

To run the separately labeled diagnostic harness:
  python3 -I independent/falsify_diagnostic.py
This changes only T57's expected refusal message; the declaration stays frozen.
Expected here: exit 1, one remaining declared exact-kill-set mismatch (X10).
The diagnostic never replaces RESULTS_v0_8_5.json.

SHA256SUMS lists every archived file except itself.
The initial independent probe output is retained to show a reviewer-test setup
error and its correction: direct verify_consequence now isolates the wrong-key
check, rather than being stopped earlier by a different witness's enrollment check.
